package com.example.studymateai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyMateApp() }
    }
}

@Composable
fun StudyMateApp() {
    var tab by remember { mutableStateOf(0) }
    val titles = listOf("Home", "Ask AI", "Scan", "Quiz", "Progress")
    Scaffold(
        topBar = { TopAppBar(title = { Text("Devdas") }) },
        bottomBar = {
            NavigationBar {
                titles.forEachIndexed { i, title ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Text(listOf("⌂","AI","▣","?","↗")[i]) },
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when(tab) {
                0 -> HomeScreen { tab = it }
                1 -> AskAiScreen()
                2 -> ScanScreen()
                3 -> QuizScreen()
                4 -> ProgressScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(onNavigate: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Namaste 👋", style = MaterialTheme.typography.headlineMedium)
            Text("Aaj kya padhna hai?", style = MaterialTheme.typography.bodyLarge)
        }
        items(listOf(
            Triple("Ask AI", "Question poochho aur simple explanation pao.", 1),
            Triple("Scan Question", "Photo se question identify karke solve karo.", 2),
            Triple("Practice", "Topic-wise practice questions karo.", 3),
            Triple("Progress", "Apni learning progress dekho.", 4)
        )) { (title, desc, dest) ->
            ElevatedCard(onClick = { onNavigate(dest) }, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text(title, style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(5.dp))
                    Text(desc)
                }
            }
        }
    }
}

@Composable
fun AskAiScreen() {
    var q by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Ask AI", style = MaterialTheme.typography.headlineSmall)
        OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Apna question likho") })
        Button(onClick = { answer = if (q.isBlank()) "Pehle question likho." else "Demo response: "$q" ko simple steps mein samjhaaya jayega. AI API connect karne ke baad yahan real answer aayega." }) {
            Text("Explain")
        }
        if (answer.isNotEmpty()) Card(Modifier.fillMaxWidth()) { Text(answer, Modifier.padding(16.dp)) }
    }
}

@Composable
fun ScanScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Scan Question", style = MaterialTheme.typography.headlineSmall)
        Text("Camera/gallery integration ke liye yahan image picker connect kiya ja sakta hai.")
        OutlinedButton(onClick = {}) { Text("Choose Photo") }
        Button(onClick = {}) { Text("Scan & Explain") }
    }
}

@Composable
fun QuizScreen() {
    var selected by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Quiz", style = MaterialTheme.typography.headlineSmall)
        Text("Demo Question: 12 × 8 = ?")
        listOf("86", "96", "108", "112").forEach { option ->
            OutlinedButton(onClick = { selected = option }, modifier = Modifier.fillMaxWidth()) { Text(option) }
        }
        if (selected.isNotEmpty()) Text(if (selected == "96") "Sahi jawab! 🎉" else "Try again.")
    }
}

@Composable
fun ProgressScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Your Progress", style = MaterialTheme.typography.headlineSmall)
        LinearProgressIndicator(progress = { 0.65f }, modifier = Modifier.fillMaxWidth())
        Text("Overall progress: 65%")
        Text("Quizzes completed: 8")
        Text("Practice questions: 124")
        Text("Topics practiced: 12")
    }
}
